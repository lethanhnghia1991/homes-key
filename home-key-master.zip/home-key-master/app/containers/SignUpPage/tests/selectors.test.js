// import { selectSignUpPageDomain } from '../selectors';

describe('selectSignUpPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
