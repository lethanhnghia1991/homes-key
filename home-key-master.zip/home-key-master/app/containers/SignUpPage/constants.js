/*
 *
 * SignUpPage constants
 *
 */

export const POST_SIGN_UP = 'app/SignUpPage/POST_SIGN_UP';
export const POST_SIGN_UP_SUCCESS = 'app/SignUpPage/POST_SIGN_UP_SUCCESS';
export const POST_SIGN_UP_FAIL = 'app/SignUpPage/POST_SIGN_UP_FAIL';

export const CHANGE_STORE_DATA = 'app/SignUpPage/CHANGE_STORE_DATA';
