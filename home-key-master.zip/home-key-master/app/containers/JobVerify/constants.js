/*
 *
 * JobVerify constants
 *
 */

export const PUT_IMAGES = 'app/JobVerify/PUT_IMAGES';
export const PUT_IMAGES_SUCCESS = 'app/JobVerify/PUT_IMAGES_SUCCESS';
export const PUT_IMAGES_FAIL = 'app/JobVerify/PUT_IMAGES_FAIL';

export const CHANGE_STORE_DATA = 'app/JobVerify/CHANGE_STORE_DATA';
