/**
 *
 * Asynchronously loads the component for JobVerify
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
