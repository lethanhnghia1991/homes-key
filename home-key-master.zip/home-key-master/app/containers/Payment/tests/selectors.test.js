// import { selectPaymentDomain } from '../selectors';

describe('selectPaymentDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
