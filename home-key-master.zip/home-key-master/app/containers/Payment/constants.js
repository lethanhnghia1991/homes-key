/*
 *
 * Payment constants
 *
 */

export const PUT_PAY = 'app/Payment/PUT_PAY';
export const PUT_PAY_SUCCESS = 'app/Payment/PUT_PAY_SUCCESS';
export const PUT_PAY_FAIL = 'app/Payment/PUT_PAY_FAIL';

export const CHANGE_STORE_DATA = 'app/Payment/CHANGE_STORE_DATA';
