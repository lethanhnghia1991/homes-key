// import { selectMotelRoomDomain } from '../selectors';

describe('selectMotelRoomDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
