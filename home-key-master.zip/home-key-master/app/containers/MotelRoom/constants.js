/*
 *
 * MotelRoom constants
 *
 */

export const GET_MOTEL = 'app/MotelRoom/GET_MOTEL';
export const GET_MOTEL_SUCCESS = 'app/MotelRoom/GET_MOTEL_SUCCESS';
export const GET_MOTEL_FAIL = 'app/MotelRoom/GET_MOTEL_FAIL';
