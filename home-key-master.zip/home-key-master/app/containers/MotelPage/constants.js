/*
 *
 * MotelPage constants
 *
 */

export const DEFAULT_ACTION = 'app/MotelPage/DEFAULT_ACTION';
