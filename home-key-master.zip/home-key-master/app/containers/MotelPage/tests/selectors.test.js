// import { selectMotelPageDomain } from '../selectors';

describe('selectMotelPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
