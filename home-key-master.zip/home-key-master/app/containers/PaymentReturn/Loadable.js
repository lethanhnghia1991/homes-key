/**
 *
 * Asynchronously loads the component for PaymentReturn
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
