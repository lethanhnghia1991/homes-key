/*
 *
 * PaymentReturn constants
 *
 */

export const GET_CALLBACK = 'app/PaymentReturn/GET_CALLBACK';
export const GET_CALLBACK_SUCCESS = 'app/PaymentReturn/GET_CALLBACK_SUCCESS';
export const GET_CALLBACK_FAIL = 'app/PaymentReturn/GET_CALLBACK_FAIL';
