/*
 *
 * HomePage constants
 *
 */

export const GET_MOTELS = 'app/HomePage/GET_MOTELS';
export const GET_MOTELS_SUCCESS = 'app/HomePage/GET_MOTELS_SUCCESS';
export const GET_MOTELS_FAIL = 'app/HomePage/GET_MOTELS_FAIL';
