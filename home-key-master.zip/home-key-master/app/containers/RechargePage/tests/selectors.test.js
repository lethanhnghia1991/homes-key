// import { selectRechargePageDomain } from '../selectors';

describe('selectRechargePageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
