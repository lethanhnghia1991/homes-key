/*
 *
 * RechargePage constants
 *
 */

export const POST_RECHARGE = 'app/RechargePage/POST_RECHARGE';
export const POST_RECHARGE_SUCCESS = 'app/RechargePage/POST_RECHARGE_SUCCESS';
export const POST_RECHARGE_FAIL = 'app/RechargePage/POST_RECHARGE_FAIL';
