/*
 *
 * RoomPage constants
 *
 */

export const GET_ROOM = 'app/RoomPage/GET_ROOM';
export const GET_ROOM_SUCCESS = 'app/RoomPage/GET_ROOM_SUCCESS';
export const GET_ROOM_FAIL = 'app/RoomPage/GET_ROOM_FAIL';
