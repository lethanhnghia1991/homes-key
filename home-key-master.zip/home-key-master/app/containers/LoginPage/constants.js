/*
 *
 * LoginPage constants
 *
 */

export const POST_LOGIN = 'app/LoginPage/POST_LOGIN';
export const POST_LOGIN_SUCCESS = 'app/LoginPage/POST_LOGIN_SUCCESS';
export const POST_LOGIN_FAIL = 'app/LoginPage/POST_LOGIN_FAIL';
