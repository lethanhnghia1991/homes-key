// import { selectAppDomain } from '../selectors';

describe('selectAppDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
