/*
 *
 * Otp constants
 *
 */

export const POST_OTP = 'app/Otp/POST_OTP';
export const POST_OTP_SUCCESS = 'app/Otp/POST_OTP_SUCCESS';
export const POST_OTP_FAIL = 'app/Otp/POST_OTP_FAIL';

export const GET_RESEND_OTP = 'app/Otp/GET_RESEND_OTP';
export const GET_RESEND_OTP_SUCCESS = 'app/Otp/GET_RESEND_OTP_SUCCESS';
export const GET_RESEND_OTP_FAIL = 'app/Otp/GET_RESEND_OTP_FAIL';

export const CHANGE_STORE_DATA = 'app/Otp/CHANGE_STORE_DATA';
