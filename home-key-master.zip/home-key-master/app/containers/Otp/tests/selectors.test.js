// import { selectOtpDomain } from '../selectors';

describe('selectOtpDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
