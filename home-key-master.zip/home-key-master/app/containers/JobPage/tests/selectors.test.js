// import { selectJobPageDomain } from '../selectors';

describe('selectJobPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
