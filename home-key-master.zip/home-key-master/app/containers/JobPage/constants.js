/*
 *
 * JobPage constants
 *
 */

export const POST_JOB = 'app/JobPage/POST_JOB';
export const POST_JOB_SUCCESS = 'app/JobPage/POST_JOB_SUCCESS';
export const POST_JOB_FAIL = 'app/JobPage/POST_JOB_FAIL';

export const CHANGE_STORE_DATA = 'app/JobPage/CHANGE_STORE_DATA';
