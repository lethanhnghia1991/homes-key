/**
 *
 * Asynchronously loads the component for AgreeTerm
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
